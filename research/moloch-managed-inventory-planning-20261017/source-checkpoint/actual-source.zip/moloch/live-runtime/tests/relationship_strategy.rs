use moloch_live_runtime::relationship_census::{self,Availability,Census,CensusCache,CensusReport,SourceEvidence,Surface};
use moloch_live_runtime::relationship_strategy as strategy;
use strategy::*;
use baal_transport_service::{Receipt,Scope,relationships};
use moloch_relationship_arbitrage::{Book,Level,Side,Source,UNIT};
use serde_json::json;
use sha2::{Digest,Sha256};
use std::{collections::{BTreeMap,BTreeSet},path::PathBuf};

const T:&str="bda92870-621e-47b0-bc3c-3602c5c26f55";
const R:&str="00000000-0000-4000-8000-000000000124";
const AT:&str="2026-10-15T09:01:00.000Z";
fn now()->u64{chrono::DateTime::parse_from_rfc3339(AT).unwrap().timestamp_millis() as u64}
fn receipt(endpoint:String,data:serde_json::Value)->Receipt{Receipt{endpoint,request_started_at:AT.into(),received_at:AT.into(),status:200,data}}
fn level(p:i128)->Vec<Level>{vec![Level{price:p,quantity:100}]}
fn surface()->Surface{Surface{availability:Availability::NotRequested,row_count:None,source:None,error_code:None,http_status:None,retry_after_ms:None}}
struct Fixture{census:Census,canonical:Receipt,certs:Vec<SettlementCertificate>,trusted:BTreeSet<String>,rules:Vec<Receipt>,books:BTreeMap<String,Book>,policy:Policy,capital:Capital}
impl Fixture{
 fn analyze(&self,positions:&[OwnedPosition])->Analysis{analyze(&self.census,&self.canonical,&Certificates{values:&self.certs,trusted_sha256:&self.trusted,rule_receipts:&self.rules},&self.books,positions,&self.capital,&self.policy)}
 fn approve(&mut self){self.trusted=self.certs.iter().map(|c|certificate_sha256(c).unwrap()).collect();}
}
fn fixture(n:usize,exhaustive:bool)->Fixture{
 let scope=Scope{tournament_id:T.into(),tournament_slug:"midterm-elections".into(),exchanges:(0..n).map(|i|((101+i).to_string(),(201+i).to_string())).collect()};
 let nodes:Vec<_>=(0..n).map(|i|json!({"exchangeId":(101+i).to_string(),"marketId":(201+i).to_string(),"marketTitle":"not a proof","outcome":"YES","currentPrice":null,"role":"member","contractId":(301+i).to_string()})).collect();
 let canonical=receipt(format!("/relationships?tournamentId={T}&depth=4"),json!({"data":[{"id":R,"type":"mutually_exclusive","source":"admin_tagged","status":"active","label":null,"reason":null,"isExhaustive":exhaustive,"expression":null,"nodes":nodes,"direction":{"kind":"symmetric","fromExchangeIds":[],"toExchangeIds":[],"description":"price metadata"},"constraint":{"description":"not a settlement certificate","priceRule":"sum <= 1","boundSemantics":"price","evaluationEndpoint":"/relationships/constraints"},"createdAt":AT,"updatedAt":AT,"version":2}],"pagination":{"limit":200,"hasMore":false,"nextCursor":null}}));
 let list=relationships::parse_list(&canonical.data,&scope).unwrap();
 let rules:Vec<_>=(0..n).map(|i|receipt(format!("/markets/{}/nodes",201+i),json!({"market_id":(201+i).to_string(),"root":{"node_id":(301+i).to_string(),"node_type":"contract","contract_id":(301+i).to_string(),"contract_type":"Election Outcome","title":"Synthetic reviewed fixture contract","settlement_date":null,"settled_with":null,"contract_details":null}}))).collect();
 let cert=SettlementCertificate{version:1,tournament_id:T.into(),relationship_id:R.into(),relationship_version:2,canonical_relationship_sha256:canonical_relationship_sha256(&list.data[0]).unwrap(),relationship_receipt_sha256:receipt_sha256(&canonical).unwrap(),issued_at_ms:now(),expires_at_ms:now()+60_000,verifier_id:"fixture-only-reviewed-rules".into(),logic:CertifiedLogic::MutuallyExclusive{exhaustive},contracts:(0..n).map(|i|ContractCertificate{exchange_id:(101+i).to_string(),market_id:(201+i).to_string(),contract_id:(301+i).to_string(),canonical_outcome:"YES".into(),rule_receipt_sha256:receipt_sha256(&rules[i]).unwrap(),rule_endpoint:rules[i].endpoint.clone(),rule_data_sha256:None,ordinary_yes_payout:"1".into(),ordinary_no_payout:"0".into(),ordinary_no_yes_payout:"0".into(),ordinary_no_no_payout:"1".into(),terminal_rules_complete:true,exceptions:vec![]}).collect()};
 let scope_sha256=format!("{:x}",Sha256::digest(serde_json::to_vec(&scope).unwrap()));
 let census=Census{report:CensusReport{version:1,started_at_ms:now(),completed_at_ms:now(),tournament_id:T.into(),scope_sha256,relationships:Surface{availability:Availability::Available,row_count:Some(1),source:Some(SourceEvidence{receipt_sha256:receipt_sha256(&canonical).unwrap(),private_file:"fixture-private.json".into(),request_started_at:AT.into(),received_at:AT.into(),status:200}),error_code:None,http_status:Some(200),retry_after_ms:None},constraints:surface(),collateral:surface(),account:surface(),graphs:BTreeMap::new(),active_relationship_count:1,exhaustive_relationship_count:usize::from(exhaustive),known_floor_component_count:0,unknown_floor_component_count:0,feed_complete:false,transport_guard_observed:false,execution_authority:false},cache:CensusCache{scope,relationships:Some(list),constraints:None,collateral:None,buying_power:None,graphs:BTreeMap::new(),private_evidence_directory:PathBuf::from("fixture-unused")}};
 let books=(0..n).map(|i|{let e=(101+i).to_string();(e.clone(),Book{exchange_id:e,source:Source{sha256:"b".repeat(64),received_ms:now()},observed_ms:now(),yes_asks:level(if n==3{300_000}else{600_000}),no_asks:level(if n==3{800_000}else if i==0{450_000}else{505_000}),yes_bids:level(290_000),no_bids:level(400_000)})}).collect();
 let policy=Policy{now_ms:now(),max_relationship_age_ms:30_000,max_rule_age_ms:3_600_000,max_book_age_ms:3000,max_book_skew_ms:1000,entry_fee_per_share_per_leg:0,buffer_per_share:5000,minimum_surplus:1,maximum_quantity:100,quantities:vec![10],maximum_retained_candidates:16};
 let capital=Capital{gross_account_cash:100*UNIT,attributed_bank_cash:20*UNIT,reserved_cash:0,maximum_committed_remaining:20*UNIT,package_cost_cap:20*UNIT,orphan_cash_loss_cap:20*UNIT};
 let mut f=Fixture{census,canonical,certs:vec![cert],trusted:BTreeSet::new(),rules,books,policy,capital};f.approve();f
}
fn blocked(a:&Analysis,code:&str){assert_eq!(a.public.blocked_reason_counts.get(code),Some(&1));assert!(a.candidates.is_empty());assert!(!a.public.execution_authority);}

struct AdmissionBank{bank:moloch_replay::session::Session,activation:moloch_live_runtime::authority::Activation,path:PathBuf}
impl Drop for AdmissionBank{fn drop(&mut self){let _=std::fs::remove_dir_all(&self.path);}}
fn admission_bank(f:&Fixture)->AdmissionBank{
 let path=std::env::temp_dir().join(format!("package-admission-{}-{}",std::process::id(),std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));
 let end=now()+60_000;let until=chrono::DateTime::from_timestamp_millis(end as i64).unwrap().to_rfc3339_opts(chrono::SecondsFormat::Millis,true);
 let policy=json!({"initialCash":"1000.000000","maximumCommitted":"1000.000000","maximumMarketCost":"100.000000","quantity":100,"maximumMarkets":3,"minimumSpreadTicks":200,"entryStopAt":until});
 let seed=json!({"runId":"package-fixture","availableCash":"1000.000000","accountSnapshotHash":"a".repeat(64),"observedAt":AT});
 let mut bank=moloch_replay::session::Session::open_live(&path,&policy,&seed).unwrap();
 for(index,(ex,b))in f.books.iter().enumerate(){
  let bids:Vec<_>=b.no_asks.iter().map(|l|json!({"price":moloch_replay::money(UNIT-l.price),"quantity":l.quantity})).collect();
  let asks:Vec<_>=b.yes_asks.iter().map(|l|json!({"price":moloch_replay::money(l.price),"quantity":l.quantity})).collect();
  let event=json!({"type":"book","receivedAt":AT,"book":{"tournamentId":T,"marketId":f.census.cache.scope.exchanges[ex],"exchangeId":ex,"sequence":"1","requestStartedAt":AT,"sourceAt":AT,"receivedAt":AT,"bids":bids,"asks":asks}});
  bank.accept("fixture-book",index as u64+1,&event).unwrap();
 }
 let activation=moloch_live_runtime::authority::Activation{run_id:"package-fixture".into(),entry_until_ms:end,maximum_committed:"1000.000000".into(),maximum_market_cost:"100.000000".into(),maximum_quantity:100,tournament_id:T.into(),tournament_slug:"midterm-elections".into(),binary_sha256:"b".repeat(64)};
 AdmissionBank{bank,activation,path}
}
fn admit_fixture(f:&Fixture,b:&AdmissionBank)->moloch_live_runtime::feedback::Result<Option<moloch_live_runtime::package_admission::Admission>>{
 moloch_live_runtime::package_admission::admit(&b.bank,&b.activation,&f.census,&f.canonical,&moloch_live_runtime::relationship_strategy::Certificates{values:&f.certs,trusted_sha256:&f.trusted,rule_receipts:&f.rules},1000*UNIT,&f.policy,b.activation.entry_until_ms)
}
#[test]fn live_package_admission_recomputes_certified_floor_and_binds_exact_bank(){
 let f=fixture(2,false);let b=admission_bank(&f);let before=b.bank.engine().report().unwrap();let a=admit_fixture(&f,&b).unwrap().unwrap();
 assert_eq!(a.basket().maximum_cost,"9.550000");assert!(a.basket().relationship_constraint.is_none());assert_eq!(a.proof()["candidate"]["relationshipId"],R);assert_eq!(a.reserve_event()["economics"]["minimumPayout"],"10.000000");assert_eq!(a.reserve_event()["economics"]["minimumSurplus"],"0.450000");assert_eq!(a.reserve_event()["bankScope"]["bankManifestHash"],*b.bank.manifest_hash());assert_eq!(a.proof_hash().len(),64);assert_eq!(b.bank.engine().report().unwrap(),before);
}
#[test]fn live_package_unapproved_rules_and_old_book_produce_no_admission(){
 let mut f=fixture(2,false);let b=admission_bank(&f);f.trusted.clear();assert!(admit_fixture(&f,&b).unwrap().is_none());f.approve();f.policy.now_ms+=3001;assert!(admit_fixture(&f,&b).unwrap().is_none());
}
#[test]fn live_package_conservative_limit_cost_can_reject_positive_weighted_depth(){
 let mut f=fixture(2,false);f.books.get_mut("102").unwrap().no_asks=vec![Level{price:505000,quantity:9},Level{price:550000,quantity:91}];
 // Ten shares cost9.595 at quoted depth, but the required0.55 wire limit reserves
 // ten shares at that limit. With the first0.45 leg, no all-state margin remains.
 let b=admission_bank(&f);assert!(admit_fixture(&f,&b).unwrap().is_none());
}
#[test]fn live_package_aggregate_quantity_and_native_scope_cannot_be_relaxed(){
 let f=fixture(2,false);let mut b=admission_bank(&f);b.activation.maximum_quantity=10;assert!(admit_fixture(&f,&b).is_err());b.activation.maximum_quantity=100;let mut f=f;f.policy.quantities=vec![60];assert!(admit_fixture(&f,&b).unwrap().is_none());b.activation.run_id="another-run".into();assert!(admit_fixture(&f,&b).is_err());
}
#[test]fn live_package_expiration_is_clipped_by_reviewed_certificate(){
 let mut f=fixture(2,false);f.certs[0].expires_at_ms=now()+5000;f.approve();let b=admission_bank(&f);assert_eq!(admit_fixture(&f,&b).unwrap().unwrap().expires_at_ms(),now()+5000);f.certs[0].expires_at_ms=now()+1000;f.approve();assert!(admit_fixture(&f,&b).unwrap().is_none());
}
#[test]fn native_reservation_cannot_be_sent_through_ordinary_order_authority(){
 use moloch_live_runtime::authority::{ProductionAuthority,SnapshotSet};
 use baal_transport_service::{Permit,RequestSpec};
 use std::sync::Arc;
 let f=fixture(2,false);let mut b=admission_bank(&f);let a=admit_fixture(&f,&b).unwrap().unwrap();
 b.bank.accept("package",1,a.reserve_event()).unwrap();let qid=b.bank.engine().order_records()[0]["id"].as_u64().unwrap();
 let binary=b.path.join("binary");std::fs::write(&binary,b"fixture").unwrap();b.activation.binary_sha256=format!("{:x}",Sha256::digest(b"fixture"));let control=b.path.join("control");std::fs::write(&control,b"immutable").unwrap();
 let lease=Arc::new(moloch_replay::session::ExclusiveLock::acquire(&b.path.join("owner.lock")).unwrap());
 let authority=ProductionAuthority::new(b.activation.clone(),f.census.cache.scope.clone(),vec![],control,binary,lease).unwrap();
 let r=receipt("/fixture".into(),json!({}));let facts=SnapshotSet{account:r.clone(),cash_balance:r.clone(),positions:r.clone(),open_orders:r.clone(),market:r.clone(),contract:r.clone(),book:r};
 let permit=Permit{run_id:b.activation.run_id.clone(),intent_id:qid.to_string(),owner:"Codex".into(),expires_at_ms:now()+5000,maximum_quantity:100,maximum_cost:"10.000000".into()};
 let spec=RequestSpec{method:"POST".into(),endpoint:"/orders".into(),body:None,body_json:None};
 assert_eq!(authority.prepare(&b.bank,qid,spec,permit,facts).unwrap_err().to_string(),"PACKAGE_REQUIRES_BASKET_AUTHORITY");
}

#[test]fn missing_certificate_blocks_despite_active_canonical_relationship(){let mut f=fixture(2,false);f.certs.clear();blocked(&f.analyze(&[]),"STRATEGY_CERTIFICATE_MISSING_OR_AMBIGUOUS");}
#[test]fn certificate_cannot_self_approve(){let mut f=fixture(2,false);f.trusted.clear();blocked(&f.analyze(&[]),"STRATEGY_CERTIFICATE_NOT_APPROVED");}
#[test]fn exact_certificate_produces_positive_private_analysis_only_candidate(){let f=fixture(2,false);let a=f.analyze(&[]);assert_eq!(a.public.certified_components,1);assert_eq!(a.candidates.len(),1);let c=&a.candidates[0];assert_eq!(c.plan.acquisition_cost,9_550_000);assert_eq!(c.plan.guaranteed_surplus,400_000);let private=c.private_json();assert_eq!(private["minimumTerminalPayout"],"10.000000");assert_eq!(private["executionAuthority"],false);assert!(private["dispatchBlockedBy"].as_array().is_some_and(|v|!v.is_empty()));}
#[test]fn public_serialization_is_counts_only(){let a=fixture(2,false).analyze(&[]);let public=serde_json::to_string(&a.public).unwrap();for private in [R,"fixture-private","contractId","9.550000","receiptSha256","profile"]{assert!(!public.contains(private));}assert!(a.candidates[0].private_json().to_string().contains("9.550000"));}
#[test]fn rule_receipt_bytes_and_contract_scope_must_match(){let mut f=fixture(2,false);f.rules[0].data["root"]["contract_id"]=json!("changed");blocked(&f.analyze(&[]),"STRATEGY_RULE_RECEIPT_MISSING_OR_AMBIGUOUS");let mut f=fixture(2,false);f.certs[0].contracts[0].contract_id="other".into();f.approve();blocked(&f.analyze(&[]),"STRATEGY_CERTIFICATE_CONTRACT_SCOPE");}
#[test]fn version_and_exact_relationship_receipt_are_bound(){let mut f=fixture(2,false);f.certs[0].relationship_version=1;f.approve();blocked(&f.analyze(&[]),"STRATEGY_CERTIFICATE_BINDING");let mut f=fixture(2,false);f.canonical.data["data"][0]["version"]=json!(3);blocked(&f.analyze(&[]),"STRATEGY_RELATIONSHIP_RECEIPT_BINDING");}
#[test]fn cache_mutation_does_not_reuse_old_receipt_proof(){let mut f=fixture(2,false);f.census.cache.relationships.as_mut().unwrap().data[0].is_exhaustive=true;blocked(&f.analyze(&[]),"STRATEGY_CANONICAL_CACHE_CHANGED");}
#[test]fn independently_declared_cancellation_removes_ordinary_floor(){let mut f=fixture(2,false);f.certs[0].contracts[0].exceptions.push(ExceptionalPayout{yes_payout:"0".into(),no_payout:"0".into()});f.approve();blocked(&f.analyze(&[]),"STRATEGY_NO_EXECUTABLE_QUALIFIED_PACKAGE");}
#[test]fn ordinary_looking_refund_is_still_exceptional(){let mut f=fixture(2,true);f.certs[0].contracts[0].exceptions.push(ExceptionalPayout{yes_payout:"0".into(),no_payout:"1".into()});f.approve();f.books.get_mut("101").unwrap().yes_asks=level(450_000);f.books.get_mut("102").unwrap().yes_asks=level(505_000);let a=f.analyze(&[]);assert!(a.candidates.iter().all(|c|c.plan.instruments.iter().any(|i|i.side==Side::No)));}
#[test]fn three_leg_exhaustive_package_is_detected(){let a=fixture(3,true).analyze(&[]);assert!(a.candidates.iter().any(|c|c.plan.instruments.len()==3&&c.plan.instruments.iter().all(|i|i.side==Side::Yes)&&c.plan.guaranteed_surplus==950_000));}
#[test]fn full_depth_and_reservations_change_eligibility(){let mut f=fixture(2,false);f.books.get_mut("102").unwrap().no_asks=vec![Level{price:505_000,quantity:1},Level{price:600_000,quantity:99}];blocked(&f.analyze(&[]),"STRATEGY_NO_EXECUTABLE_QUALIFIED_PACKAGE");let mut f=fixture(2,false);f.capital.reserved_cash=11*UNIT;blocked(&f.analyze(&[]),"STRATEGY_NO_EXECUTABLE_QUALIFIED_PACKAGE");}
#[test]fn marginal_held_inventory_value_is_preserved(){let a=fixture(2,false).analyze(&[OwnedPosition{exchange_id:"101".into(),side:Side::No,quantity:10}]);let c=&a.candidates[0];assert_eq!(c.existing_component_floor,0);assert_eq!(c.marginal_floors,vec![0,10*UNIT]);}
#[test]fn incomplete_list_and_missing_books_block(){let mut f=fixture(2,false);f.canonical.data["pagination"]["hasMore"]=json!(true);f.canonical.data["pagination"]["nextCursor"]=json!("next");f.census.report.relationships.source.as_mut().unwrap().receipt_sha256=receipt_sha256(&f.canonical).unwrap();blocked(&f.analyze(&[]),"STRATEGY_RELATIONSHIPS_INCOMPLETE");let mut f=fixture(2,false);f.books.remove("102");blocked(&f.analyze(&[]),"STRATEGY_EXECUTABLE_BOOK_MISSING");}
#[test]fn old_certificate_and_old_relationships_cannot_be_activated(){let mut f=fixture(2,false);f.certs[0].expires_at_ms=now();f.approve();blocked(&f.analyze(&[]),"STRATEGY_CERTIFICATE_CLOCK_OR_VERIFIER");let mut f=fixture(2,false);f.policy.now_ms+=30_001;blocked(&f.analyze(&[]),"STRATEGY_RECEIPT_STALE");}
#[test]fn candidate_retention_is_bounded_without_hiding_positive_count(){let mut f=fixture(2,false);f.policy.quantities=vec![1,2,10];f.policy.maximum_retained_candidates=1;let a=f.analyze(&[]);assert_eq!(a.public.positive_candidates,3);assert_eq!(a.public.retained_candidates,1);assert_eq!(a.candidates[0].plan.quantity,10);}
#[test]fn available_empty_official_feed_is_distinct_from_forbidden(){
 let mut f=fixture(2,false);f.canonical.data["data"]=json!([]);f.census.cache.relationships=Some(relationships::parse_list(&f.canonical.data,&f.census.cache.scope).unwrap());f.census.report.relationships.availability=Availability::Empty;f.census.report.relationships.row_count=Some(0);f.census.report.relationships.source.as_mut().unwrap().receipt_sha256=receipt_sha256(&f.canonical).unwrap();
 let a=f.analyze(&[]);assert_eq!(a.public.canonical_feed_state,"available_empty");assert_eq!(a.public.canonical_relationships,0);assert_eq!(a.public.positive_candidates,0);assert!(a.public.blocked_reason_counts.is_empty());
 f.census.report.relationships.availability=Availability::Forbidden;let a=f.analyze(&[]);assert_eq!(a.public.canonical_feed_state,"forbidden");blocked(&a,"STRATEGY_RELATIONSHIPS_UNAVAILABLE");
}
