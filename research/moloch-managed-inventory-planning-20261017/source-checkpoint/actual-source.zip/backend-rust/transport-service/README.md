# Standalone Rust official transport

`baal-transport-service` is a reusable Rust library and executable. It performs documented API v1 HTTP requests directly through reqwest and Windows native TLS. It has no Node runtime, PowerShell credential-decryption subprocess, per-book child process, browser-internal endpoint or API-key creation code. The checked Rust account-admission implementation is compiled directly through `src/admission.rs`; the sibling `account-queue` source must therefore be published with it.

All development tests use invented credentials and local loopback HTTP servers. No real key, account request, order, service activation or existing runtime modification was performed. The default executable uses `DisabledCredentials`, `ReadOnlyAuthority`, and forcibly disables writes even when a supplied config says otherwise. `--approved-dpapi-reads` is an explicit prospective read-access option, not an execution activation. Do not run it beside the existing account collector.

Build/check with `./build.ps1 -Test`. The locked standard dependencies include reqwest, native-tls, serde/serde_json arbitrary precision, SHA-256, chrono, zeroize and native Windows security APIs. The release executable retains one HTTP client/connection pool and one in-process admission queue for its lifetime. The client disables redirects and environment proxy routing, verifies TLS by default, uses 10-second connect / 20-second complete-response limits, and bounds response bodies at 8 MiB. It never logs auth headers, credentials, request bodies, raw HTTP errors or account data; typed receipts are intended for the owning backend's data channel and must not be copied into diagnostic logs.

The public library entry point is:

```rust
Transport::new(config, credentials, clock, authority)?;
transport.request(Endpoint::Tournament)?;
transport.request(Endpoint::OrderBook { market_id, depth: 20 })?;
transport.reconcile()?;
transport.compact()?;
```

`Config` contains an absolute queue directory, one shared account-scope identifier, immutable tournament/exchange→market mapping, maximum pagination count and a default-false writes flag. `Clock`, `CredentialProvider` and `Authority` are trusted Rust traits, not JSON booleans. Mutable access serializes all operations; shared use must borrow the same transport under one mutex rather than instantiate independent queues. Its local exclusive queue lock is not a distributed account lock. Parent integration must retain the existing actual owner/STOP/legacy-worker locks and prevent all duplicate account clients and keys from bypassing this one queue.

The supported typed reads cover tournament, complete unpaginated positions, paginated orders/owned-order fills/portfolio fills, market details, root contracts, depth20 books, separately identified depth200 recovery books, up to100 scoped bulk prices, minute candles and daily portfolio P&L. Page cursors are encoded, duplicates/repeated cursors/incomplete coverage are rejected, and every row is checked against the configured tournament/market/exchange scope. Positions remain observed account data, never adopted as this bot's inventory. Reconciliation provides precise observation timestamps and exact cash but does not assert atomicity across changing account endpoints. The caller must still perform its fresh intent/contract/book reconciliation and liability attribution.

Receipts use camelCase `endpoint`, UTC `requestStartedAt`, UTC `receivedAt`, `status`, and `data`. JSON numeric lexemes are retained by serde arbitrary precision. Financial arithmetic converts exact decimal/scientific decimal text into integer micro-units; nonzero precision beyond six places and overflow fail instead of rounding through floating point. Tick, one-order quantity and permit cost checks precede admission. Wire order prices are canonical exact JSON numbers, not string-valued API prices.

The queue retains 1000 ms read /2500 ms write completion pacing, conservative inclusive 60-read /24-write rolling caps, durable Retry-After/backoff, manual-review overflow and clock-regression fences. A successful HTTP write is not sufficient: canonical side/action/quantity/price/economics must agree. Ambiguous connection/body/5xx/in-flight acknowledgments and inconsistent 2xx bodies retain unknown acceptance and block replacements across restart. Any returned order ID survives in the typed error for reconciliation. Intent, idempotency key and exact scoped payload hashes remain immutable; automatic write retry is absent. Explicit source-anchored compaction preserves all bindings, counters, reservations and unknowns. The lifetime binding/audit history is never silently pruned.

`place(Order, Permit)` and `cancel(owned_order_id, Permit)` are implemented as library building blocks. Every dispatch must pass an actual `Authority` twice plus a final immediately-before-network check. The typed permit is separately bounded by owner, expiration, quantity and gross order cost; the constructor's authority must enforce human activation, fresh exact account/books/contracts, cumulative/exposure budgets, durable intent ownership, cancellation attribution and safe canonical conversion policy. `ReadOnlyAuthority` rejects every write. A caller implementing an always-true trait would be bypassing these integration obligations; config data and agent statements are not authority. `reconcile_unknown` additionally requires the trusted authority's exact scoped reconciliation callback and never permits replacement retries of an old key.

`WindowsDpapiCredentials::approved_default()` locates only the already approved `LOCALAPPDATA/SigTradingCup/api-key.dpapi`. Loading checks native file and directory ownership/DACL against the current Windows user plus SYSTEM/Administrators, rejects unrestricted/unsupported ACLs, parses the existing PowerShell DPAPI hex encoding, decrypts through `CryptUnprotectData`, and clears plaintext buffers. It neither imports an environment key nor creates credentials, weakens ACLs, displays decryption output or invokes a shell. Native DPAPI/ACL code compiles on Windows; it was deliberately not exercised against the real storage during development. Parent migration must verify compatibility prospectively under the approved Windows account; a failed ACL/format check remains a failure, not permission to relax storage.

For a fresh migration queue, the parent must prove the old account owner and in-flight requests are quiescent, retain all attributed inventory/journals/unknown dispatches, then call `reserve_legacy_migration_boundary(old_next_or_cooldown, old_manual_review)` before any other queue command. It preserves the larger existing delay plus a full quiet 60,001 ms rolling window, and latches legacy manual review. It cannot overwrite a resumed Rust history. This avoids an empty new queue forgetting old account-rate reservations; it grants no order authority and does not reconcile legacy execution intents by itself.

The optional `offline-fixtures` feature exposes `new_for_mock` exclusively for loopback HTTP test servers. Tests cover actual HTTP routes, exact decimal bodies, canonical acknowledgment mismatch, pagination, complete account observations, network-time authority loss, read/write backoff after restart, uncertain-write replacement fencing, missing credentials, redirect refusal and migration pacing. The sibling durable-core correctness/fault tests are compiled into the same suite. Synthetic HTTP fixtures establish correctness, not trading profit or live API speed. Publish source/Cargo.lock/build script/README only; exclude target binaries, journals, locks, configs with private data and all credential storage.

API contract sources are the repository's official `openapi.json`, `api-guide.txt`, existing checked scope validators in `execution/transport.mjs`, and the official [automation/API policy](https://sig.thesuper.market/docs/markets-and-trading). Platform account limits apply to all keys and clients together; a faster language does not increase those limits.

Unix production-integration prerequisite: `UnixFileCredentials::approved_file`
can read an explicitly provisioned absolute runtime-key path. It never creates
or transfers credentials. It requires private current-user-owned directory and
file permissions, rejects symlinks and changed inode/device bindings, bounds
reads and zeroizes key buffers. Linux uses Rustls; Windows retains native TLS
and the existing DPAPI provider. The optional `--approved-file-reads ABS_FILE`
CLI path is read-only and does not grant execution authority or enable writes.
No real key was provisioned on the VPS during these fixture tests.

Per-share API price validation now reuses Baal's enumerated canonical-tick and
IEEE complement representations. The observed NO-price representation
0.06000000000000005 is accepted as the official 0.060000 tick; arbitrary near-tick
values are rejected. This conversion does not apply to cash or realized P&L.
Reported position summaries and placement `totalCost` remain raw diagnostic
numbers; they do not fund the live bank or replace individual executed fills.

The new_with_read_budget constructor configures a fresh queue's immutable read
profile. Existing queues retain their original 60/1000 defaults unless they
were initialized with an explicit profile; a profile cannot be silently changed.
The initial migration boundary preserves a quiet account minute.
Full-account observation permits well-formed foreign holdings/orders to be
observed without expanding placement scope or owned-order permissions.
The typed realtime_token method mints short-lived authentication material
through read admission; callers must keep it in memory, bound mint frequency,
and reserve token headroom beneath the exchange write limit.
