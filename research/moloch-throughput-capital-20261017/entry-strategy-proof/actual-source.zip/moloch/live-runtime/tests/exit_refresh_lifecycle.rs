//! Actual source tracker + durable native Session, fixed virtual clocks only.
//! No HTTP/client/worker dispatch is exercised or authorized by this fixture.
use baal_transport_service::{Receipt,Scope};
use moloch_live_runtime::exit_refresh::{BookAcceptance,ReadHint,RefreshFacts,RefreshPlan,RefreshStage,Safety};
use moloch_replay::{session::{Session,BatchEntry},source::RestSource,Side};
use serde_json::{Value,json};
use sha2::{Digest,Sha256};
use std::{collections::BTreeMap,fs,path::PathBuf,sync::atomic::{AtomicU64,Ordering},time::{SystemTime,UNIX_EPOCH}};
const TOURNAMENT:&str="11111111-1111-4111-8111-111111111111";
const SLUG:&str="offline-lifecycle";
fn at(ms:u64)->String{let base=chrono::DateTime::parse_from_rfc3339("2026-10-15T00:00:00Z").unwrap().timestamp_millis();chrono::DateTime::from_timestamp_millis(base+ms as i64).unwrap().to_rfc3339_opts(chrono::SecondsFormat::Millis,true)}
fn ms(relative:u64)->u64{chrono::DateTime::parse_from_rfc3339(&at(relative)).unwrap().timestamp_millis()as u64}
fn scope()->Scope{Scope{tournament_id:TOURNAMENT.into(),tournament_slug:SLUG.into(),exchanges:BTreeMap::from([("2".into(),"1".into())])}}
struct Fixture{root:PathBuf,bank:Session,source:RestSource,hint:ReadHint,old:Value,cutoff:u64}
impl Drop for Fixture{fn drop(&mut self){/* Session owns its lock until field drop; fixtures are synthetic and retained. */}}
fn head(f:&Fixture)->[u8;32]{Sha256::digest(fs::read(f.root.join("bank/head.json")).unwrap()).into()}
fn safety(f:&Fixture)->Safety{Safety{never_attempted:true,has_intent:false,unresolved_attempts:false,global_unknown:false,stop:false,stream_healthy:true,owned_quantity:f.bank.engine().wallet.quantity("2",Side::Yes),reserved_sell_quantity:0,same_exchange_pending_physical_order:false,lifecycle_fingerprint:Sha256::digest(serde_json::to_vec(&f.bank.engine().report().unwrap()).unwrap()).into(),native_head_fingerprint:head(f)}}
fn commit(bank:&mut Session,events:&[Value],processed:u64)->Vec<Value>{
 let first=bank.last_source_sequence("offline-lifecycle")+1;let stamped=events.iter().map(|e|{let mut e=e.clone();e["processedAt"]=json!(at(processed));e}).collect::<Vec<_>>();
 let input=stamped.iter().enumerate().map(|(i,event)|BatchEntry{source_id:"offline-lifecycle",sequence:first+i as u64,event}).collect::<Vec<_>>();let result=bank.accept_batch(&input).unwrap();assert_eq!(result.appended_rows,events.len());assert!(result.accepted.iter().all(|v|*v));stamped
}
fn fixture()->Fixture{
 static N:AtomicU64=AtomicU64::new(0);let root=std::env::temp_dir().join(format!("moloch-exit-lifecycle-{}-{}-{}",std::process::id(),SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos(),N.fetch_add(1,Ordering::SeqCst)));fs::create_dir(&root).unwrap();#[cfg(unix)]{use std::os::unix::fs::PermissionsExt;fs::set_permissions(&root,fs::Permissions::from_mode(0o700)).unwrap();}
 let policy=json!({"quantity":1,"maximumInventoryAgeMs":1000,"minimumQuoteAgeMs":10000,"inventoryAgeClock":"execution","retainProfitableHedge":false});let seed=json!({"runId":"offline-source-lifecycle","availableCash":"1000.000000","accountSnapshotHash":"a".repeat(64),"observedAt":at(0)});let mut bank=Session::open_live(&root.join("bank"),&policy,&seed).unwrap();
 let book=json!({"type":"book","receivedAt":at(0),"book":{"tournamentId":TOURNAMENT,"marketId":"1","exchangeId":"2","sequence":"1","requestStartedAt":at(0),"sourceAt":at(0),"receivedAt":at(0),"bids":[{"price":"0.450000","quantity":1000}],"asks":[{"price":"0.455000","quantity":1000}]}});commit(&mut bank,&[book],0);
 let records=bank.engine().order_records();let yes=records.iter().find(|q|q["side"]=="YES"&&q["action"]=="buy").unwrap().clone();let no=records.iter().find(|q|q["side"]=="NO"&&q["action"]=="buy").unwrap().clone();
 let actual=|kind:&str,time:u64|json!({"type":kind,"source":"official_sig_api_v1","receiptHash":"b".repeat(64),"orderId":yes["id"],"actualOrderId":"201","exchangeId":"2","marketId":"1","side":"YES","action":"buy","quantity":1,"price":yes["price"],"receivedAt":at(time)});
 commit(&mut bank,&[actual("actual_order_ack",3000)],3000);let mut fill=actual("actual_fill",5000);fill["fillId"]=json!("301");fill["fee"]=json!("0.000000");fill["executedAt"]=json!(at(4000));commit(&mut bank,&[fill],5000);
 let mut terminal=actual("actual_order_terminal",5100);terminal["status"]=json!("filled");terminal["filledQuantity"]=json!(1);terminal["fillsComplete"]=json!(true);commit(&mut bank,&[terminal],5100);
 let retired=json!({"type":"unsubmitted_intent_retired","source":"moloch_live_dispatcher","receiptHash":"c".repeat(64),"orderId":no["id"],"confirmedNetworkAttempts":0,"receivedAt":at(5500)});commit(&mut bank,&[retired],5500);
 let old=bank.engine().order_records().into_iter().find(|q|q["action"]=="sell"&&q["inventoryExitReason"]=="maximumAge"&&q["retired"]==false).expect("actual held lot creates original maximum-age SELL");
 assert_eq!(old["activationAt"].as_u64().unwrap()-old["createdAt"].as_u64().unwrap(),3000);assert_eq!(old["expiresAt"].as_u64().unwrap()-old["createdAt"].as_u64().unwrap(),13000);
 let source=RestSource::new(&json!([{"marketId":"1","exchangeId":"2"}]),TOURNAMENT,&at(15000)).unwrap();
 // The hint comes from actual native output and actual held quantity, not a
 // hand-built successor. Journal/queue flags describe this offline no-dispatch fixture.
 let mut f=Fixture{root,bank,source,hint:ReadHint::from_expired(&old,Safety{never_attempted:true,has_intent:false,unresolved_attempts:false,global_unknown:false,stop:false,stream_healthy:true,owned_quantity:1,reserved_sell_quantity:0,same_exchange_pending_physical_order:false,lifecycle_fingerprint:[1;32],native_head_fingerprint:[1;32]},ms(20000)).unwrap(),old,cutoff:0};
 f.cutoff=f.bank.engine().order_records().iter().map(|q|q["id"].as_u64().unwrap()).max().unwrap();
 let cleanup=json!({"type":"unsubmitted_intent_retired","source":"moloch_live_dispatcher","receiptHash":"d".repeat(64),"orderId":f.old["id"],"confirmedNetworkAttempts":0,"receivedAt":at(20100)});commit(&mut f.bank,&[cleanup],20100);assert_eq!(f.bank.engine().wallet.quantity("2",Side::Yes),1);f
}
fn coverage(partial:bool)->Value{json!({"kind":"trades","source":"official_sig_api_v1","status":200,"marketId":"1","exchangeId":"2","tournamentId":TOURNAMENT,"requestStartedAt":at(19000),"receivedAt":at(19500),"endpoint":format!("/exchanges/2/trades?tournamentId={TOURNAMENT}&from={}&to={}",at(14000),at(19000)),"data":{"marketId":"1","exchangeId":"2","from":at(14000),"to":at(19000),"data":[],"pagination":{"hasMore":partial,"nextCursor":if partial{json!("next-page")}else{Value::Null}},"coverage":{"complete":true,"projectedThroughSequence":100}}})}
fn receipts()->[Receipt;7]{
 let context=json!([{"type":"tournament","tournament":{"id":TOURNAMENT},"status":"open"}]);let data=[json!({"id":TOURNAMENT,"slug":SLUG,"status":"active","myBalance":999.55}),json!({"positions":[{"exchangeId":"2","marketId":"1","quantity":1,"lots":[{"lotId":"301","side":"YES","quantity":1,"entryPrice":0.45,"openedAt":at(4000)}]}]}),json!({"data":[],"coverage":{"complete":true},"pagination":{"hasMore":false,"nextCursor":null}}),json!({"balance":999.55,"availableAdvance":0,"buyingPower":999.55}),json!({"id":"1","status":"open","isComposite":false,"isMultiOutcome":false,"contexts":context}),json!({"market_id":"1","root":{"node_type":"contract","id":"offline-contract"},"contexts":context}),json!({"contexts":[{"type":"tournament","tournament":{"id":TOURNAMENT},"orderbook":{"exchanges":[{"exchangeId":"2","asOf":{"sequence":100,"at":at(26000)},"bids":[{"price":0.45,"quantity":1000}],"asks":[{"price":0.455,"quantity":1000}]}]}}]})];
 let endpoints=[format!("/tournaments/{SLUG}"),format!("/tournaments/{SLUG}/portfolio/positions"),format!("/orders?status=open&limit=200&tournamentId={TOURNAMENT}"),format!("/account?tournamentId={TOURNAMENT}"),format!("/markets/1?tournamentId={TOURNAMENT}"),format!("/markets/1/nodes?tournamentId={TOURNAMENT}"),format!("/markets/1/orderbook?tournamentId={TOURNAMENT}&depth=20")];
 std::array::from_fn(|i|Receipt{endpoint:endpoints[i].clone(),status:200,request_started_at:at(20000+i as u64*1000),received_at:at(20500+i as u64*1000),data:data[i].clone()})
}
fn wrapped(book:&Receipt)->Value{json!({"source":"official_sig_api_v1","kind":"book","tournamentId":TOURNAMENT,"marketId":"1","exchangeId":"2","endpoint":book.endpoint,"status":book.status,"requestStartedAt":book.request_started_at,"receivedAt":book.received_at,"data":book.data})}
fn recover(f:&mut Fixture)->(RefreshFacts,Vec<Value>){
 let coverage=f.source.accept(&coverage(false)).unwrap();assert_eq!(coverage.len(),1);assert_eq!(coverage[0]["type"],"coverage");commit(&mut f.bank,&coverage,20200);assert_eq!(f.source.scopes()[0]["blocked"],true);
 let raw=receipts();let facts=RefreshFacts::new(&scope(),&f.hint,raw.clone(),ms(27000)).unwrap();let events=f.source.accept(&wrapped(&raw[6])).unwrap();assert_eq!(events.len(),2);assert_eq!(events[0]["book"]["invalid"],true);assert_ne!(events[1]["book"]["invalid"],true);let admitted=commit(&mut f.bank,&events,27000);assert_eq!(f.source.scopes()[0]["blocked"],false);(facts,admitted)
}
#[test]fn complete_tape_then_real_invalid_valid_books_commit_and_certify_original_new_quote(){
 let mut f=fixture();let(facts,events)=recover(&mut f);let proof=BookAcceptance::from_events(&facts,&events,true,head(&f),ms(27000),ms(27100)).unwrap();
 let q=f.bank.engine().order_records().into_iter().find(|q|q["id"].as_u64().unwrap()>f.cutoff&&q["action"]=="sell"&&q["inventoryExitReason"]=="maximumAge"&&q["retired"]==false).unwrap();let original=q.clone();let candidates=f.bank.engine().order_records();let safe=safety(&f);
 let plan=RefreshPlan::select(&facts,&proof,&candidates,f.cutoff,ms(20000),ms(27100),ms(27100),|_|safe).unwrap();assert_eq!(plan.quote(),&q);assert_eq!(plan.stage(&q,&facts,&scope(),safe,ms(27100)).unwrap(),RefreshStage::WaitUntil(ms(30000)));assert_eq!(plan.stage(&q,&facts,&scope(),safe,ms(30000)).unwrap(),RefreshStage::Ready);assert_eq!(q,original);assert_ne!(q["id"],f.old["id"]);assert_eq!(q["expiresAt"],ms(40000));
 // Read the actual sealed journal and report, rather than treating the Boolean
 // helper argument as independent proof that Session committed the source.
 let rows=fs::read_to_string(f.root.join("bank/events.jsonl")).unwrap().lines().map(|s|serde_json::from_str::<Value>(s).unwrap()).collect::<Vec<_>>();let tail=&rows[rows.len()-2..];for(i,row)in tail.iter().enumerate(){let mut actual=row["event"].clone();assert!(actual.as_object_mut().unwrap().remove("sourceRef").is_some());assert_eq!(actual,events[i]);}let report:Value=serde_json::from_slice(&fs::read(f.root.join("bank/report.json")).unwrap()).unwrap();assert_eq!(report["report"],f.bank.engine().report().unwrap());assert_eq!(report["report"]["fills"],1);assert_eq!(report["report"]["realized"],"0.000000");
}
#[test]fn missing_or_unfinished_tape_keeps_real_book_invalid_and_denies_certificate(){for partial in [false,true]{let mut f=fixture();if partial{let output=f.source.accept(&coverage(true)).unwrap();assert!(output.is_empty());}let raw=receipts();let facts=RefreshFacts::new(&scope(),&f.hint,raw.clone(),ms(27000)).unwrap();let events=f.source.accept(&wrapped(&raw[6])).unwrap();assert_eq!(events.len(),1);assert_eq!(events[0]["book"]["invalid"],true);let actual=commit(&mut f.bank,&events,27000);assert!(BookAcceptance::from_events(&facts,&actual,true,head(&f),ms(27000),ms(27100)).is_err());assert_eq!(f.source.scopes()[0]["blocked"],true);assert_eq!(f.bank.engine().report().unwrap()["fills"],1);}}
#[test]fn actual_later_source_gap_invalidates_previously_valid_committed_book(){let mut f=fixture();let(facts,mut events)=recover(&mut f);let gap=f.source.subscribed_market("1",&at(27200)).unwrap();assert!(gap.iter().any(|e|e["type"]=="gap"&&e["exchangeId"]=="2"));events.extend(commit(&mut f.bank,&gap,27200));assert!(BookAcceptance::from_events(&facts,&events,true,head(&f),ms(27000),ms(27300)).is_err());assert_eq!(f.source.scopes()[0]["blocked"],true);}
#[test]fn certificate_does_not_promote_uncommitted_events_or_ambiguous_actual_valid_emissions(){let mut f=fixture();let(facts,mut events)=recover(&mut f);assert!(BookAcceptance::from_events(&facts,&events,false,head(&f),ms(27000),ms(27100)).is_err());let raw=receipts();let repeated=f.source.accept(&wrapped(&raw[6])).unwrap();assert_eq!(repeated.len(),1);assert_ne!(repeated[0]["book"]["invalid"],true);events.extend(commit(&mut f.bank,&repeated,27200));assert!(BookAcceptance::from_events(&facts,&events,true,head(&f),ms(27000),ms(27300)).is_err());}

fn deny_initial_uncovered_book(f:&mut Fixture){
 let raw=receipts();let facts=RefreshFacts::new(&scope(),&f.hint,raw.clone(),ms(27000)).unwrap();let output=f.source.accept(&wrapped(&raw[6])).unwrap();assert_eq!(output.len(),1);assert_eq!(output[0]["book"]["invalid"],true);let admitted=commit(&mut f.bank,&output,27000);
 assert!(BookAcceptance::from_events(&facts,&admitted,true,head(f),ms(27000),ms(27100)).is_err());assert_eq!(f.source.scopes()[0]["blocked"],true);assert_eq!(f.source.scopes()[0]["bookReady"],true);assert_eq!(f.source.scopes()[0]["tapeReady"],false);
}
fn repair_window(earliest:u64,unfinished:bool,miss_boundary:bool)->Value{
 let from=earliest-ms(0)+if miss_boundary{2000}else{0};json!({"kind":"trades","source":"official_sig_api_v1","status":200,"marketId":"1","exchangeId":"2","tournamentId":TOURNAMENT,"requestStartedAt":at(28000),"receivedAt":at(28500),"endpoint":format!("/exchanges/2/trades?tournamentId={TOURNAMENT}&from={}&to={}",at(from),at(28000)),"data":{"marketId":"1","exchangeId":"2","from":at(from),"to":at(28000),"data":[],"pagination":{"hasMore":unfinished,"nextCursor":if unfinished{json!("remaining-page")}else{Value::Null}},"coverage":{"complete":true,"projectedThroughSequence":101}}})
}
fn later_facts(f:&Fixture)->(RefreshFacts,[Receipt;7]){
 let mut raw=receipts();for(i,r)in raw.iter_mut().enumerate(){r.request_started_at=at(29000+i as u64*1000);r.received_at=at(29500+i as u64*1000);}
 raw[6].data["contexts"][0]["orderbook"]["exchanges"][0]["asOf"]=json!({"sequence":101,"at":at(35000)});
 let facts=RefreshFacts::new(&scope(),&f.hint,raw.clone(),ms(36000)).unwrap();(facts,raw)
}
#[test]fn same_session_denial_then_exact_tape_repair_then_later_seven_facts_reaches_ready(){
 let mut f=fixture();deny_initial_uncovered_book(&mut f);let flow_cutoff=f.bank.engine().order_records().iter().map(|q|q["id"].as_u64().unwrap()).max().unwrap();let earliest=f.source.recovery_start_ms("1").unwrap();assert_eq!(earliest,ms(14999));
 let window=repair_window(earliest,false,false);let recovery=f.source.accept(&window).unwrap();assert_eq!(recovery.len(),2);assert_eq!(recovery[0]["type"],"coverage");assert_eq!(recovery[0]["from"],at(14999));assert_eq!(recovery[0]["to"],at(28000));assert_eq!(recovery[1]["type"],"book");assert_ne!(recovery[1]["book"]["invalid"],true);let recovered=commit(&mut f.bank,&recovery,28600);
 assert_eq!(f.source.scopes()[0]["tapeReady"],true);assert_eq!(f.source.scopes()[0]["blocked"],false);assert!(f.source.recovery_start_ms("1").is_none());
 // Coverage can legitimately release a valid cached book and create the new
 // successor BEFORE the seven snapshots. Its original deadline must survive.
 let original=f.bank.engine().order_records().into_iter().find(|q|q["id"].as_u64().unwrap()>flow_cutoff&&q["action"]=="sell"&&q["inventoryExitReason"]=="maximumAge"&&q["retired"]==false).unwrap();assert_eq!(original["createdAt"],ms(28600));assert_eq!(original["activationAt"],ms(31600));assert_eq!(original["expiresAt"],ms(41600));
 let(facts,raw)=later_facts(&f);assert!(BookAcceptance::from_events(&facts,&recovered,true,head(&f),ms(28600),ms(28700)).is_err());
 let output=f.source.accept(&wrapped(&raw[6])).unwrap();assert_eq!(output.len(),1);assert_ne!(output[0]["book"]["invalid"],true);let admitted=commit(&mut f.bank,&output,36000);let proof=BookAcceptance::from_events(&facts,&admitted,true,head(&f),ms(36000),ms(36100)).unwrap();
 let candidates=f.bank.engine().order_records();let current=candidates.iter().find(|q|q["id"]==original["id"]).unwrap();assert_eq!(current,&original);let safe=safety(&f);let plan=RefreshPlan::select(&facts,&proof,&candidates,flow_cutoff,ms(27500),ms(36100),ms(36100),|_|safe).unwrap();assert_eq!(plan.quote(),&original);assert_eq!(plan.stage(current,&facts,&scope(),safe,ms(36100)).unwrap(),RefreshStage::Ready);assert_ne!(plan.quote()["id"],f.old["id"]);assert_eq!(f.bank.engine().report().unwrap()["fills"],1);assert_eq!(f.bank.engine().report().unwrap()["realized"],"0.000000");
}
#[test]fn causal_repair_with_partial_pages_or_missing_boundary_cannot_reach_ready(){
 for(unfinished,miss_boundary)in [(true,false),(false,true)]{let mut f=fixture();deny_initial_uncovered_book(&mut f);let earliest=f.source.recovery_start_ms("1").unwrap();let output=f.source.accept(&repair_window(earliest,unfinished,miss_boundary)).unwrap();let admitted=commit(&mut f.bank,&output,28600);assert!(admitted.iter().all(|e|e["type"]!="book"));assert_eq!(f.source.scopes()[0]["tapeReady"],false);assert_eq!(f.source.scopes()[0]["blocked"],true);assert_eq!(f.source.recovery_start_ms("1"),Some(earliest));
  let(facts,raw)=later_facts(&f);let invalid=f.source.accept(&wrapped(&raw[6])).unwrap();assert_eq!(invalid.len(),1);assert_eq!(invalid[0]["book"]["invalid"],true);let committed=commit(&mut f.bank,&invalid,36000);assert!(BookAcceptance::from_events(&facts,&committed,true,head(&f),ms(36000),ms(36100)).is_err());assert_eq!(f.bank.engine().report().unwrap()["fills"],1);assert_eq!(f.bank.engine().wallet.quantity("2",Side::Yes),1);
 }
}
