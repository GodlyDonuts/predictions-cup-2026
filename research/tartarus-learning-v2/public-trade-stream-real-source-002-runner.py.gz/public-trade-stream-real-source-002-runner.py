import hashlib,json,os,time
from pathlib import Path
from moloch.learning_actions.experiment import Experiment
from moloch.learning_actions.episode_training import release_worlds
from moloch.learning_actions.continue_population import verify_source

root=Path(os.environ['LOCALAPPDATA'])/'Moloch/learning-v2'
job=root/'studies/public-trade-stream-real-source-002'
source=verify_source(Path.cwd())
config=json.loads((root/'handoffs/population-019-to-020-full-returns-v2/next-config.json').read_bytes())
fields=('tournament_id','exchange_id','market_id','match_id','available_at_ms','received_at_ms',
        'executed_at_ms','yes_price_micros','quantity','original_sha256')
def facts(row):return [row[k]for k in fields]
def digest(rows):return hashlib.sha256(json.dumps(rows,separators=(',',':')).encode()).hexdigest()
reports=[];pins=None
for public in(False,True):
    c=dict(config,device='cpu',cpu_threads=1,derived_public_trade_stream=public)
    x=Experiment(c,job/('enabled'if public else'default-off'))
    try:
        start=x.train_bounds[0]+1200000;end=start+900000;e=x.world('train',start,end)
        connected=e.busy_until;observed=[];visible=[];accept=e.flow.accept
        def record(at,row):
            result=accept(at,row)
            if result:
                observed.append(facts(row));o=e.observe();i=o['entities'].index(('contract',row['exchange_id']))
                visible.append(float(o['contracts'][i,21])==float(at-row['executed_at_ms']<=60000))
            return result
        e.flow.accept=record
        began=time.perf_counter();e.advance(end);elapsed=time.perf_counter()-began
        expected=[facts(row)for row in x.tape('train').flow_rows if connected<row['available_at_ms']<end]if public else[]
        assert observed==expected,('ORIGINAL_RECEIPT_FACTS_DIFFER',len(observed),len(expected))
        assert all(visible)
        assert not e.budget.reads and e.realtime.mints==1 and len(e.budget.request_ids)==1
        assert not e.api_fills and e.cash==e.initial_wealth
        result={'enabled':public,'start_ms':start,'end_ms':end,'connected_at_ms':connected,
                'expected_receipts':len(expected),'actual_receipts':len(observed),
                'expected_fact_sha256':digest(expected),'actual_fact_sha256':digest(observed),
                'exact_fields_and_order':observed==expected,'all_observed_feature_flags_match':all(visible),
                'reads':e.feed_request_counts['SIG'],'writes':e.realtime.mints,'total_distinct_admissions':len(e.budget.request_ids),'fills':len(e.api_fills),
                'cash_unchanged':True,'derived_public_deliveries':e.realtime.public_deliveries,
                'recorded_gap_signals':e.realtime.gaps,'elapsed_seconds':elapsed,
                'model_or_optimizer_created':False}
        reports.append(result);print(json.dumps(result),flush=True);pins=x.frozen['source_sha256']
        release_worlds([e])
    finally:x.close()
proof={'classification':'real_recorded_train_receipt_conformance_not_full_raw_stream_parity_or_roi',
       'sourceCommit':source['commit'],'datasetManifestSha256':x.dataset_sha,'runtimeSourceSha256':pins,
       'cases':reports,'runnerSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
       'httpRequests':0,'gpuModelOrDiagnostic':False,'independentTestUsed':False,'productionChanged':False}
(job/'RESULT.json').write_text(json.dumps(proof,indent=2)+'\n')
