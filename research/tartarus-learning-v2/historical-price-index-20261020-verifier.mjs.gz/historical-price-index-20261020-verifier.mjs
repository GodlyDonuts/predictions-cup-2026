import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const [root,repo,output]=process.argv.slice(2),sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const helper=path.join(repo,'moloch/learning_actions/historical-price-index.mjs'),{sampleAtSourceTime,RECORD_BYTES}=await import(pathToFileURL(helper));
const reports=[];
for(const [folder,auditName]of [['polymarket-train-price-index-001','polymarket-historical-recovery-001.json'],['polymarket-evolution-price-index-001','polymarket-evolution-recovery-001.json']]){
 const began=performance.now(),directory=path.join(root,folder),raw=await fs.readFile(path.join(directory,'complete.json')),m=JSON.parse(raw),auditRaw=await fs.readFile(path.join(repo,'research/tartarus-learning-v2',auditName)),audit=JSON.parse(auditRaw);
 assert.equal(m.sourceAuditSha256,sha(auditRaw));assert.equal(m.trainingAdmitted,false);
 const receiptRaw=await fs.readFile(path.join(directory,'receipts.json'));assert.equal(sha(receiptRaw),m.receiptsSha256);const receipts=JSON.parse(receiptRaw);
 const normal=crypto.createHash('sha256');let count=0,totalBytes=0,bench=null;
 for(let a=0;a<m.assets.length;a++){
  const asset=m.assets[a],bytes=await fs.readFile(path.join(directory,asset.file));assert.equal(sha(bytes),asset.sha256);assert.equal(bytes.length,asset.records*RECORD_BYTES);totalBytes+=bytes.length;let prior=-1;
  for(let i=0;i<asset.records;i++){
   const offset=i*RECORD_BYTES,t=Number(bytes.readBigInt64LE(offset)),p=bytes.readDoubleLE(offset+8),r=bytes.readUInt32LE(offset+16);assert(t>prior&&t>=m.startTs*1000&&t<m.endExclusiveTs*1000);assert(Number.isFinite(p)&&p>=0&&p<=1);assert.equal(bytes.readUInt32LE(offset+20),1);assert.equal(receipts[r].assetId,asset.assetId);assert(Date.parse(receipts[r].actualReceivedAt)>=t);normal.update(JSON.stringify([asset.assetId,t/1000,p])+'\n');prior=t;count++;
  }
  if(a===0&&asset.records>1){const first=Number(bytes.readBigInt64LE(0)),last=Number(bytes.readBigInt64LE((asset.records-1)*RECORD_BYTES)),begin=performance.now();let found=0;const queries=1000000;for(let i=0;i<queries;i++){const t=first+(i*7919)%(last-first+1);const point=sampleAtSourceTime(bytes,t);assert(point.sourceTimeMs<=t);assert.equal(point.originalDeliveryVerified,false);found+=point.receipt;}bench={queries,wallMs:performance.now()-begin,receiptChecksum:found,classification:'warm_single_asset_source_time_lookup_not_full_training_benchmark'};}
 }
 const digest=normal.digest('hex');assert.equal(digest,audit.normalizedScopedSampleSha256);assert.equal(count,audit.uniqueInRangeSamples);
 reports.push({role:m.role,manifestSha256:sha(raw),normalizedDecodedSha256:digest,assets:m.assets.length,records:count,packedDataBytes:totalBytes,buildWallMs:m.buildWallMs,independentDecodeAuditWallMs:performance.now()-began,lookupBenchmark:bench,allPackedBytesAndReceiptReferencesVerified:true,trainingAdmitted:false,originalHistoricalDeliveryVerified:false});
}
const proof={observedUtc:new Date().toISOString(),classification:'independently_decoded_historical_price_indexes_not_training_admission',sourceCommit:'c2567e89534bf89cac7d1cab9f6f35ce5af1ee19',indexerSha256:sha(await fs.readFile(helper)),verifierSha256:sha(await fs.readFile(process.argv[1])),reports,independentTestUsed:false,productionChanged:false,gpuDiagnostic:false};
await fs.writeFile(output,JSON.stringify(proof,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(reports));
