// CPU/filesystem-only receipt audit. Run with PRIVATE_RECOVERY_ROOT OUTPUT_JSON.
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { pathToFileURL,fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';
const [root,output]=process.argv.slice(2);
const source=path.join(root,'polymarket-checked-source-002');
const { validate,scopedPoints }=await import(pathToFileURL(path.join(source,'moloch/learning_actions/backfill_polymarket_history.mjs')));
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const snapshot=JSON.parse(await fs.readFile(path.join(source,'source.json')));
for(const [name,digest]of Object.entries(snapshot.files))assert.equal(sha(await fs.readFile(path.join(source,name))),digest);
const job=path.join(root,'polymarket-train-prices-002'),planBytes=await fs.readFile(path.join(job,'plan.json')),plan=JSON.parse(planBytes);
assert.equal(plan.role,'training_history_recovery_only');
assert.equal(plan.runnerSha256,sha(await fs.readFile(path.join(source,'moloch/learning_actions/backfill_polymarket_history.mjs'))));
const status=JSON.parse(await fs.readFile(path.join(job,'status.json')));assert.equal(status.state,'complete_receipt_recovery_not_replay_qualification');assert.equal(status.trainingAdmitted,false);
let pages=0,bytes=0,records=0,duplicates=0,excluded=0,first=null,last=null;
const inventory=crypto.createHash('sha256'),normal=crypto.createHash('sha256'),daily={},assets=[];const expectedFiles=new Set();
for(let i=0;i<plan.assets.length;i++){
 const asset=plan.assets[i],seen=new Map();let chunk=0;
 for(let lo=plan.startTs;lo<plan.endTs;lo+=7*86400,chunk++){
  const hi=Math.min(plan.endTs,lo+7*86400),name=`${String(i).padStart(4,'0')}-${chunk}.json`,file=path.join(job,'pages',name);expectedFiles.add(name);
  const before=await fs.stat(file),raw=await fs.readFile(file),receipt=JSON.parse(raw),count=validate(receipt,asset,lo,hi);
  const after=await fs.stat(file);assert.equal(before.size,after.size);assert.equal(before.mtimeMs,after.mtimeMs);
  inventory.update(name);inventory.update(Buffer.from(sha(raw),'hex'));bytes+=raw.length;pages++;excluded+=count.excludedOutOfRange;
  for(const r of scopedPoints(receipt,asset,lo,hi)){
   if(seen.has(r.t)){assert.equal(seen.get(r.t),r.p);duplicates++;continue;}
   seen.set(r.t,r.p);
  }
 }
 const times=[...seen.keys()].sort((a,b)=>a-b);let gap=0;
 for(let n=0;n<times.length;n++){
  const t=times[n];if(n)gap=Math.max(gap,t-times[n-1]);const day=new Date(t*1000).toISOString().slice(0,10);daily[day]=(daily[day]??0)+1;
  normal.update(JSON.stringify([asset,t,seen.get(t)])+'\n');first=first===null?t:Math.min(first,t);last=last===null?t:Math.max(last,t);
 }
 records+=times.length;assets.push({assetId:asset,records:times.length,firstEventTs:times[0]??null,lastEventTs:times.at(-1)??null,maximumInternalSampleGapSeconds:times.length>1?gap:null});
}
const actual=(await fs.readdir(path.join(job,'pages'))).filter(n=>n.endsWith('.json')&&!n.includes('.error-'));assert.deepEqual(new Set(actual),expectedFiles);
assert.equal(records+duplicates,status.records);assert.equal(excluded,status.excludedOutOfRange);
const report={observedUtc:new Date().toISOString(),classification:'verified_public_price_samples_not_executable_depth_or_original_delivery',sourceCommit:snapshot.commit,planSha256:sha(planBytes),runnerSha256:sha(await fs.readFile(fileURLToPath(import.meta.url))),role:plan.role,startTs:plan.startTs,endExclusiveTs:plan.endTs,assets:plan.assets.length,assetsWithHistoricalSamples:assets.filter(x=>x.records>0).length,receiptPages:pages,receiptBytes:bytes,uniqueInRangeSamples:records,duplicatesVerified:duplicates,excludedOutOfRange:excluded,sortedReceiptInventorySha256:inventory.digest('hex'),normalizedScopedSampleSha256:normal.digest('hex'),firstEventUtc:new Date(first*1000).toISOString(),lastEventUtc:new Date(last*1000).toISOString(),dailySampleCounts:daily,perAsset:assets,allOriginalHashesAndQueryScopesVerified:true,outOfRangePricesNotInspectedByAudit:true,originalHistoricalDeliveryVerified:false,historicalOrderBooksRecovered:false,trainingAdmitted:false,independentTestUsed:false,productionChanged:false,gpuDiagnostic:false};
await fs.writeFile(output,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({assets:report.assets,samples:records,duplicates,excluded,pages,receiptBytes:bytes,first:report.firstEventUtc,last:report.lastEventUtc}));
