import os,json,collections,hashlib,math,sys
from pathlib import Path
from moloch.learning_actions.experiment import Experiment
from moloch.learning_actions.contract import OrderSpec,TICK,UNIT
from moloch.learning_actions.economics import GrowthLedger
quantity=int(sys.argv[1])
if quantity not in(100,1000):raise ValueError('DECLARED_PAPER_SIZE_REQUIRED')
root=Path(os.environ['LOCALAPPDATA'])/'Moloch/learning-v2';r=root/'runs/raw-api-growth-development-021';job=root/f'studies/activity-maker-train-probe-002-q{quantity}';job.mkdir(exist_ok=False)
c=json.loads((r/'experiment.json').read_bytes())['config'];c.update(device='cpu',cpu_threads=1);x=Experiment(c,job/'runtime-pin');reports=[];latency=json.loads((root/'runs/raw-api-growth-development-020/compute-calibration.json').read_bytes())['decision_latency_ms']
try:
 for offset in(1200000,3000000):
  for stress in(False,True):
   start=x.train_bounds[0]+offset;end=start+900000;e=x.world('train',start,end,stress=stress);ledger=GrowthLedger(e,development=True,historical_last_mark=True);counts=collections.Counter();seq=0;cursor=book_cursor=0;maximum_valid=0;activity_scores={};activity_clock=start
   ever_quoted=set();ever_traded=set();print_samples=[]
   original_trade=e.passive.trade
   def audited_trade(at,row):
    if row['tournament_id']==e.passive.tournament:
     counts['source_prints']+=1
     ex=row['exchange_id'];price=row['yes_price_micros'];ever_traded.add(ex)
     counts['source_print_minute_phase_'+str(((at-start)%60000)//10000)]+=1
     live=[o for o in e.api_orders.values()if o.placed_at_ms<at and(o.spec.expiration_ms is None or at<o.spec.expiration_ms)]
     if live:counts['prints_during_any_live_quote']+=1
     if ex in ever_quoted:counts['prints_on_previously_quoted_exchange']+=1
     if len(print_samples)<20:print_samples.append({'delta_ms':at-start,'live_quotes':len(live),'on_ever_quoted':ex in ever_quoted})
     resting=[o for o in e.api_orders.values()if o.spec.exchange==ex and o.placed_at_ms<at
         and(o.spec.expiration_ms is None or at<o.spec.expiration_ms)]
     if resting:
      counts['prints_with_own_resting_quotes']+=1;counts['volume_with_own_resting_quotes']+=row['quantity']
      strict=equal=False
      for order in resting:
       spec=order.spec;yes=spec.price if spec.side=='YES'else UNIT-spec.price
       buying_yes=(spec.action=='BUY')==(spec.side=='YES')
       strict=strict or(buying_yes and yes>price)or(not buying_yes and yes<price)
       equal=equal or yes==price
      if strict:counts['prints_strictly_through_own_limit']+=1
      if equal:counts['prints_at_own_limit']+=1
    return original_trade(at,row)
   e.passive.trade=audited_trade
   def move(target):e.advance(min(end,max(e.now,int(target))))
   def think(n=1):move(e.now+latency*n)
   def read(key):
    think()
    if e.now>=end:return
    res=e.request_observation('SIG',key);counts['read_'+res['status']]+=1
    if res['status']=='IN_FLIGHT':move(e.busy_until)
   def dispatch(operation,specs=None):
    global seq
    think()
    if e.now>=end:return
    seq+=1;res=e.dispatch(operation,specs,idempotency_key=f'baseline:{seq}');counts[operation+'_'+res['status']]+=1
    if res['status']=='IN_FLIGHT':
     move(e.busy_until);counts[operation+'_receipt_'+res['status']]+=1
     if operation=='BATCH':
      counts['batch_legs_requested']+=len(specs)
      for leg in res.get('result',[]):
       label=('not_admitted'if leg is None else 'rejected:'+leg if isinstance(leg,str)else 'accepted_order')
       counts['batch_leg_'+label]+=1
       if leg is not None and not isinstance(leg,str):ever_quoted.add(leg.spec.exchange)
      counts['maximum_open_orders']=max(counts['maximum_open_orders'],len(e.api_orders))
   while e.now<end-5000:
    target=e.now+60000
    if e.budget.active is not None:move(min(end-5000,e.busy_until));continue
    ready=e.budget.ready_at(e.now,True)
    if ready>e.now:move(min(end-5000,ready));continue
    at=e.now;decay=2**(-(at-activity_clock)/300000.)
    for ex in e.exchanges[1:]:
     activity_scores[ex]=max(activity_scores.get(ex,0.)*decay,e.flow.observe(ex,at)[2])
    activity_clock=at
    desired=sorted([ex for ex,v in activity_scores.items()if v>0 and('book',ex)in e.keys['SIG']],key=lambda ex:(-activity_scores[ex],ex))[:25]
    counts['maximum_activity_markets']=max(counts['maximum_activity_markets'],len(desired))
    if not desired:
     counts['no_observed_activity_waits']+=1;move(min(end-5000,e.now+5000));continue
    read(('positions',));read(('account',))
    for ex in desired:read(('book',ex))
    dispatch('CANCEL_ALL')
    orders=[];available=[]
    for ex in e.exchanges[1:]:
     if ex not in desired:continue
     q=e.actor_books.get(ex)
     if q is None or not q.visible(e.now,60000)or not q.book.bids or not q.book.asks:continue
     bid,ask=q.book.bids[0][0],q.book.asks[0][0];price=bid+TICK if ask-bid>=3*TICK else bid
     no_price=UNIT-(ask-TICK if ask-bid>=3*TICK else ask)
     if TICK<=price<=UNIT-TICK and price<ask and TICK<=no_price<=UNIT-TICK:available.append((ex,price,no_price))
    maximum_valid=max(maximum_valid,len(available))
    if available:
     remaining=max(0,50-len(orders));ordered=sorted(available,key=lambda row:(-activity_scores[row[0]],row[0]))
     for ex,price,no_price in ordered[:remaining//2]:
      orders.extend((OrderSpec(ex,'YES','BUY',quantity,price,e.now+60000),OrderSpec(ex,'NO','BUY',quantity,no_price,e.now+60000)))
     cursor=(cursor+remaining//2)%len(available)
    if orders:
     think(len(orders))
     if e.now<end-5000:dispatch('BATCH',orders[:50])
    move(min(end-5000,e.now+30000))
   if e.now<end:
    if e.budget.active is not None:move(e.busy_until)
    if e.budget.ready_at(e.now,True)<=e.now:dispatch('CANCEL_ALL')
    read(('positions',));liquidation=[OrderSpec(ex,side,'SELL',sum(q for q,_ in lots))for(ex,side),lots in sorted(e.known_lots.items())if sum(q for q,_ in lots)]
    for i in range(0,len(liquidation),50):
     batch=liquidation[i:i+50];think(len(batch))
     if e.now+e.mechanics.arrival_latency_ms+e.mechanics.receipt_latency_ms<end:dispatch('BATCH',batch)
   move(end);result=ledger.finish();remaining=sum(sum(q for q,p in lots)for lots in e.lots.values())
   if remaining==0:assert e.cash-e.initial_wealth==e.realized,'FLAT_REALIZED_CASH_CONSISTENCY_REQUIRED'
   report={'start_ms':start,'end_ms':end,'stress':stress,'quote_quantity':quantity,'public_trade_deliveries':e.realtime.public_deliveries,'marked_roi':result['marked_roi'],'terminal_cash_roi':e.cash/e.initial_wealth-1,'reward':result['reward'],'fill_count':len(e.api_fills),'realized_fifo_micros':e.realized,'cash_change_micros':e.cash-e.initial_wealth,'remaining_shares':remaining,'fully_flat':remaining==0,'valuation':result['valuation'],'stale_mark_observations':result['stale_mark_observations'],'stale_mark_exchanges':result['stale_mark_exchanges'],'maximum_valid_delivered_quote_markets':maximum_valid,'ever_quoted_exchanges':len(ever_quoted),'ever_traded_exchanges':len(ever_traded),'quoted_and_traded_exchanges':len(ever_quoted&ever_traded),'print_samples':print_samples,'fill_origins':dict(collections.Counter(f['execution_model']for f in e.api_fills)),'passive_source_volume':e.passive.source_volume,'passive_intercepted_volume':e.passive.intercepted_volume,'passive_unknown_liquidity_volume':e.passive.unknown_liquidity_print_volume,'operations':dict(counts)};reports.append(report);print(json.dumps(report),flush=True)
   for pending in e.clock._events:
    if pending[3]=='api_source_cursor':pending[-1].rows.close()
 proof={'classification':'delivered_information_paired_maker_training_only_baseline_not_independent_profit_or_neural_policy','datasetManifestSha256':x.dataset_sha,'cases':reports,'decisionCostMs':latency,'refreshAnchor':'after_processing_and_quote_receipt_not_iteration_start','episodeMs':900000,'quoteQuantity':quantity,'refreshMs':30000,'bookTargets':'received-activity-ranked-first25','activityHalfLifeMs':300000,'publicTradeStreamEnabled':True,'noOptimizerStep':True,'noGpuDiagnostic':True,'httpRequests':0,'independentTestUsed':False,'productionChanged':False,'actorStateSources':['received60sflowvolume and locallydecayed activity memory','delivered actor_books after paid baselines','paid positions/account receipts','public catalog/local state'],'earlierFailures':['001 omitted required paid book baselines and never submitted batches','002 regressed the local loop clock at closing cutoff; no score credited'],'runnerSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'runtimeSourceSha256':x.frozen['source_sha256']}
 (job/'RESULT.json').write_text(json.dumps(proof,indent=2)+'\n')
finally:x.close()
