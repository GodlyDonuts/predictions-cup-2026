import ast,hashlib,json,os,statistics,subprocess,time
from pathlib import Path
from unittest.mock import patch
import numpy as np
import moloch.learning_actions.engine as engine
from moloch.learning_actions.experiment import Experiment
from moloch.learning_actions.episode_training import release_worlds
from moloch.learning_actions.continue_population import verify_source
from moloch.learning_actions.contract import OrderSpec

root=Path(os.environ['LOCALAPPDATA'])/'Moloch/learning-v2'
job=root/'studies/entity-identities-real-source-001'
source=verify_source(Path.cwd())
repository=Path(os.environ['MOLOCH_BENCH_REPOSITORY'])
reference_commit='9383f27ce4f5868c94a39328a2e38db878c81d72'
reference_source=subprocess.check_output(['git','show',reference_commit+':moloch/learning_actions/engine.py'],cwd=repository)
tree=ast.parse(reference_source);definition=next(n for n in tree.body if isinstance(n,ast.ClassDef)and n.name=='ApiEpisode')
method=next(n for n in definition.body if isinstance(n,ast.FunctionDef)and n.name=='observe')
assert 'entity_identities'not in ast.unparse(method)
namespace=dict(vars(engine));exec(compile(ast.Module(body=[method],type_ignores=[]),'<pinned_reference_observe>','exec'),namespace)
reference=namespace['observe'];candidate=engine.ApiEpisode.observe
config=json.loads((root/'handoffs/population-020-to-021-learning-utilization-v3/spec.json').read_bytes())['template']
config.update(device='cpu',cpu_threads=1);x=Experiment(config,job/'runtime-pin')
timings={'reference':[],'candidate':[]};checked=0;max_entities=0
try:
    start=x.train_bounds[0]+1200000;end=start+900000;e=x.world('train',start,end)
    e.advance(e.busy_until)
    for key in[k for k in e.keys['SIG']if k[0]=='book'][:8]:
        result=e.request_observation('SIG',key)
        if result['status']=='IN_FLIGHT':e.advance(e.busy_until)
    def check(a,b):
        assert a.keys()==b.keys()
        for key in a:
            if isinstance(a[key],np.ndarray):assert a[key].dtype==b[key].dtype and a[key].shape==b[key].shape and a[key].tobytes()==b[key].tobytes(),key
            elif isinstance(a[key],dict):
                assert a[key].keys()==b[key].keys()
                for field in a[key]:assert a[key][field].dtype==b[key][field].dtype and a[key][field].shape==b[key][field].shape and a[key][field].tobytes()==b[key][field].tobytes(),(key,field)
            else:assert a[key]==b[key],key
    for i in range(90):
        e.advance(e.now+500)
        e.quote_selection=list(e.exchanges[1:1+i%5])
        e.builder=([OrderSpec(e.exchanges[1],'YES','BUY',1,5000,e.now+60000)]if i%3 else[])
        observations={}
        order=('reference','candidate')if i%2 else('candidate','reference')
        for name in order:
            with patch.object(engine.ApiEpisode,'observe',reference if name=='reference'else candidate):
                began=time.perf_counter_ns();observations[name]=e.observe();elapsed=time.perf_counter_ns()-began
            if i>=10:timings[name].append(elapsed/1e6)
        check(observations['reference'],observations['candidate']);checked+=1
        max_entities=max(max_entities,len(observations['candidate']['entities']))
    a=statistics.median(timings['reference']);b=statistics.median(timings['candidate'])
    proof={'classification':'paired_cpu_observation_conformance_and_timing_not_gpu_or_end_to_end_speedup_or_roi',
        'sourceCommit':source['commit'],'referenceCommit':reference_commit,
        'referenceEngineSourceSha256':hashlib.sha256(reference_source).hexdigest(),
        'datasetManifestSha256':x.dataset_sha,'runtimeSourceSha256':x.frozen['source_sha256'],
        'checkedObservationPairs':checked,'timedPairs':len(timings['reference']),'maxEntities':max_entities,
        'allFieldsAndMasksBitwiseEqual':True,'medianReferenceMs':a,'medianCandidateMs':b,'medianRatio':a/b,
        'timingsMs':timings,'actorModelCreated':False,'optimizerCreated':False,'gpuDiagnostic':False,
        'independentTestUsed':False,'productionChanged':False,'httpRequests':0,
        'runnerSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (job/'RESULT.json').write_text(json.dumps(proof,indent=2)+'\n')
    print(json.dumps({k:proof[k]for k in ['checkedObservationPairs','timedPairs','maxEntities','medianReferenceMs','medianCandidateMs','medianRatio']}))
    release_worlds([e])
finally:x.close()
